# NuxIA WhatsApp Bridge

Servidor de conexión WhatsApp para NuxIA usando Baileys.

## Variables de entorno requeridas
- `N8N_WEBHOOK_URL` — URL del webhook de N8n que recibe los mensajes
- `PORT` — Puerto (Railway lo asigna automáticamente)

## Endpoints
- `GET /` — Status del servicio
- `GET /qr` — Ver QR para conectar WhatsApp
- `GET /status` — Estado de la conexión
- `POST /send` — Enviar mensaje `{ "to": "numero", "message": "texto" }`
